plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.orbis.keyboard"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.orbis.keyboard"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }
}
