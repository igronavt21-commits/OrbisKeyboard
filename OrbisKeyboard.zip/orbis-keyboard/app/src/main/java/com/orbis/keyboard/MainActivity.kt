package com.orbis.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFFF5F6F8.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Orbis Keyboard"
            textSize = 28f
            setTextColor(0xFF172033.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Первая тестовая версия · 0.1.0\n\nЛокальная клавиатура с тремя раскладками.\nСетевые разрешения приложению не нужны."
            textSize = 16f
            setTextColor(0xFF536078.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 28)
        })
        root.addView(actionButton("1. Включить Orbis Keyboard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(actionButton("2. Выбрать Orbis Keyboard") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })
        root.addView(TextView(this).apply {
            text = "Важно: это ранний прототип. Пока доступны базовый ввод и переключение RU / UK / EN. Интеллектуальное предсказание, словари и проверка грамматики будут добавляться следующими этапами."
            textSize = 13f
            setTextColor(0xFF6B7280.toInt())
            setPadding(0, 28, 0, 0)
        })
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 }
    }
}
