package com.orbis.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OrbisImeService : InputMethodService() {
    private var languageIndex = 0
    private val languages = listOf("RU", "UK", "EN")
    private lateinit var root: LinearLayout
    private lateinit var suggestionRow: LinearLayout
    private var secureField = false

    private val layouts = mapOf(
        "RU" to listOf("й ц у к е н г ш щ з х", "ф ы в а п р о л д ж э", "я ч с м и т ь б ю"),
        "UK" to listOf("й ц у к е н г ш щ з х ї", "ф і в а п р о л д ж є", "я ч с м и т ь б ю ґ"),
        "EN" to listOf("q w e r t y u i o p", "a s d f g h j k l", "z x c v b n m")
    )

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 8)
            setBackgroundColor(Color.rgb(224, 228, 235))
        }
        suggestionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        root.addView(suggestionRow)
        renderSuggestions()
        renderKeys()
        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        val inputType = attribute?.inputType ?: 0
        val variation = inputType and android.text.InputType.TYPE_MASK_VARIATION
        secureField = variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        if (::root.isInitialized) renderSuggestions()
    }

    private fun renderSuggestions() {
        if (!::suggestionRow.isInitialized) return
        suggestionRow.removeAllViews()
        val options = if (secureField) emptyList() else listOf("Orbis", "Привет", "Сегодня")
        options.forEach { word ->
            suggestionRow.addView(Button(this).apply {
                text = word
                textSize = 13f
                isAllCaps = false
                setOnClickListener { currentInputConnection?.commitText(word, 1) }
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
        }
        val langButton = Button(this).apply {
            text = languages[languageIndex]
            textSize = 12f
            isAllCaps = false
            setOnClickListener {
                languageIndex = (languageIndex + 1) % languages.size
                renderKeys()
                renderSuggestions()
            }
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(42))
        }
        suggestionRow.addView(langButton)
    }

    private fun renderKeys() {
        if (!::root.isInitialized) return
        while (root.childCount > 1) root.removeViewAt(1)
        layouts[languages[languageIndex]].orEmpty().forEach { rowText ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            rowText.split(" ").forEach { key ->
                row.addView(keyButton(key) { commit(key) }, LinearLayout.LayoutParams(0, dp(45), 1f).apply {
                    setMargins(2, 2, 2, 2)
                })
            }
            root.addView(row)
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(keyButton("?123") { commit("?123") }, weightParams(1f))
        controls.addView(keyButton(",") { commit(",") }, weightParams(0.7f))
        controls.addView(keyButton("Пробел") { currentInputConnection?.commitText(" ", 1) }, weightParams(3f))
        controls.addView(keyButton("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) }, weightParams(0.9f))
        controls.addView(keyButton("↵") { sendEnter() }, weightParams(0.9f))
        root.addView(controls)
    }

    private fun keyButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = if (label.length > 1) 12f else 18f
        isAllCaps = false
        setTextColor(Color.rgb(28, 35, 48))
        typeface = Typeface.DEFAULT
        setPadding(0, 0, 0, 0)
        minHeight = 0
        minimumHeight = 0
        setOnClickListener { action() }
    }

    private fun commit(value: String) {
        if (value == "?123") return // Numeric/symbol layout is a later milestone.
        currentInputConnection?.commitText(value, 1)
    }

    private fun sendEnter() {
        val ic: InputConnection = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun weightParams(weight: Float) = LinearLayout.LayoutParams(0, dp(46), weight).apply {
        setMargins(2, 2, 2, 2)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
